/**
 * Created by iankibet on 2016/02/01.
 */

$('input[name="deadline"]').datetimepicker();
